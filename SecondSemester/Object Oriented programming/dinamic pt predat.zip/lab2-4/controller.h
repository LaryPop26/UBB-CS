//
// Created by popla on 11-Mar-25.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#include "MyList.h"

typedef struct {
    MyList lstParticipants;
}ManagerParticipants;

/*
 * Creates a manager for contest participants
 * return: created ManagerParticipants
 */
ManagerParticipants createManagerParticipants();

/*
 * Destroy everything about the partipants manager
 * param: manager - ManagerParticipants, manager for participants
 */
void destroyManagerParticipants(ManagerParticipants* manager);

/*
 * Add a participant
 * params: manager - ManagerParticipants, manager for participants
 *         lastName - char, name of a person
 *         firstName - char, name of a person
 *         score - int, score of the participant
 * return: 0..3 - succes of process
 */
int addParticipantController(ManagerParticipants* manager, char* lastName, char* firstName, int score);

/*
 * Update a participant score
 * params: manager - ManagerParticipants, manager for participants
 *         lastName - char, name of a person
 *         firstName - char, name of a person
 *         score - int, score of the participant
 * return: 0..3 - succes of process
 */
int updateParticipantController(ManagerParticipants* manager, char* lastName, char* firstName, int score);

/*
 * Delete a participant
 * params: manager - ManagerParticipants, manager for participants
 *         poz - int, position to be cleared
 * return: 0..1 - succes of process
 */
int deleteParticipantController(ManagerParticipants* manager, int poz);

/*
 * Creates a new list with all participant having score less than given value
 * param: manager - ManagerParticipants, manager for participants
 *        score - int, score to be compared with
 * return: MyList, a list with valid data for given condition
 */
MyList filterScore(ManagerParticipants* manager, int score);

/*
 * Creates a new list with all participant having the first letter of lastname the given one
 * param: manager - ManagerParticipants, manager for participants
 *        firstLetter - char, compared letter
 * return: MyList, a list with valid data for given condition
 */
MyList filterFirstLetter(ManagerParticipants* manager, char* firstLetter);

/*
 * Sort a list of participants after lastname, in ascending order
 * param: manager - ManagerParticipants, manager for participants
 * return: a sorted list by ascending names
 */
MyList sortByNameA(ManagerParticipants* manager);

/*
 * Sort a list of participants after lastname, in descending order
 * param: manager - ManagerParticipants, manager for participants
 * return: a sorted list by descending names
 */
MyList sortByNameD(ManagerParticipants* manager);

/*
 * Sort a list of participants after score, in ascending order
 * param: manager - ManagerParticipants, manager for participants
 * return: a sorted list by ascending scores
 */
MyList sortByScoreA(ManagerParticipants* manager);

/*
 * Sort a list of participants after lastname, in descending order
 * param: manager - ManagerParticipants, manager for participants
 * return: a sorted list by desscending scores
 */
MyList sortByScoreD(ManagerParticipants* manager);

#endif //CONTROLLER_H
