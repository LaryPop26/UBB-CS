//
// Created by popla on 11-Mar-25.
//

#include <string.h>
#include "controller.h"
#include "MyList.h"
#include "validation.h"
#include "mysort.h"

ManagerParticipants createManagerParticipants() {
    ManagerParticipants manager;
    manager.lstParticipants = createEmpty();
    return manager;
}

void destroyManagerParticipants(ManagerParticipants* manager) {
    destroyMyList(&manager->lstParticipants);
}

int addParticipantController(ManagerParticipants* manager, char* lastName, char* firstName, int score) {
    Participant p = createParticipant(lastName, firstName, score);
    int valCode = validate_entity(p);
    if (valCode != 1) {
        destroyParticipant(&p);
        return valCode;
    }
    if (findElem(&manager->lstParticipants, lastName, firstName) != -1) {
        destroyParticipant(&p);
        return -1;
    }
    addElem(&manager->lstParticipants, p);
    return 0;
}

int updateParticipantController(ManagerParticipants* manager, char* lastName, char* firstName, int score) {
    Participant participant = createParticipant(lastName, firstName, score);
    int valCode = validate_entity(participant);
    if (valCode != 1) {
        destroyParticipant(&participant);
        return valCode;
    }
    if (findElem(&manager->lstParticipants, lastName, firstName) == -1) {
        destroyParticipant(&participant);
        return -1;
    }
    updateElem(&manager->lstParticipants, participant);
    return 0;
}

int deleteParticipantController(ManagerParticipants* manager, int poz) {
    int valCode = validate_int(poz);
    if (valCode != 1) {
        return valCode;
    }
    if (poz >= size(&manager->lstParticipants)) return 2;
    Participant p = deleteElem(&manager->lstParticipants, poz);
    destroyParticipant(&p);
    return 0;
}

MyList filterScore(ManagerParticipants* manager, int score) {
    if (score < 0) return copyMyList(&manager->lstParticipants);
    MyList filteredList = createEmpty();
    for (int i = 0; i < size(&manager->lstParticipants); i++) {
        Participant p = getMyElement(&manager->lstParticipants, i);
        if (p.score<score) addElem(&filteredList, copyParticipant(&p));
    }
    return filteredList;
}

MyList filterFirstLetter(ManagerParticipants* manager, char* firstLetter) {
    if (strlen(firstLetter)!=1) return copyMyList(&manager->lstParticipants);
    MyList filteredList = createEmpty();
    for (int i = 0; i < size(&manager->lstParticipants); i++) {
        Participant p = getMyElement(&manager->lstParticipants, i);
        if (strncmp(p.lastName,firstLetter,1) == 0) addElem(&filteredList, copyParticipant(&p));
    }
    return filteredList;
}

int cmpNameA(Participant* p1, Participant* p2) {
    return strcmp(p1->lastName, p2->lastName);
}

int cmpNameD(Participant* p1, Participant* p2) {
    return -strcmp(p1->lastName, p2->lastName);
}

int cmpScoreAscending(Participant* p1, Participant* p2) {
    return p1->score > p2->score;
}

int cmpScoreDescending(Participant* p1, Participant* p2) {
    return p1->score < p2->score;
}

MyList sortByNameA(ManagerParticipants* manager) {
    MyList sortedList = copyMyList(&manager->lstParticipants);
    sort(&sortedList, cmpNameA);
    return sortedList;
}

MyList sortByNameD(ManagerParticipants* manager) {
    MyList sortedList = copyMyList(&manager->lstParticipants);
    sort(&sortedList, cmpNameD);
    return sortedList;
}

MyList sortByScoreA(ManagerParticipants* manager) {
    MyList sortedList = copyMyList(&manager->lstParticipants);
    sort(&sortedList, cmpScoreAscending);
    return sortedList;
}

MyList sortByScoreD(ManagerParticipants* manager) {
    MyList sortedList = copyMyList(&manager->lstParticipants);
    sort(&sortedList, cmpScoreDescending);
    return sortedList;
}
