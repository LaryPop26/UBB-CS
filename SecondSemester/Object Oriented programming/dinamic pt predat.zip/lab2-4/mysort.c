//
// Created by popla on 13-Mar-25.
//

#include "mysort.h"
void sort(MyList* myList, CmpFct cmp) {
    for (int i = 0; i < size(myList) - 1; i++) {
        for (int j = i + 1; j < size(myList); j++) {
            if (cmp(&myList->elems[i], &myList->elems[j]) > 0) {
                Participant temp = copyParticipant(&myList->elems[i]);
                myList->elems[i] = myList->elems[j];
                myList->elems[j] = temp;
            }
        }
    }
}