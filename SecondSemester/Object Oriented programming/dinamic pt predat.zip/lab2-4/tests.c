//
// Created by popla on 12-Mar-25.
//
#include "tests.h"

#include "controller.h"

// entity tests:
void  testCreateParticipant() {
    Participant participant = createParticipant("Ionescu", "Paula",50);
    assert(strcmp(participant.lastName, "Ionescu") == 0);
    assert(strcmp(participant.firstName,"Paula")==0);
    assert(participant.score == 50);

    destroyParticipant(&participant);
    assert(participant.lastName == NULL);
    assert(participant.firstName == NULL);
    assert(participant.score == -1);
}

// MyList tests:

void testIterateList() {
    MyList l = createEmpty();
    assert(size(&l) == 0);
    addElem(&l, createParticipant("Ionescu", "Paula", 60));
    addElem(&l, createParticipant("Popa", "Ioana", 50));
    assert(size(&l) == 2);

    assert(strcmp(getMyElement(&l, 0).lastName, "Ionescu") == 0);
    assert(getMyElement(&l, 0).score == 60);

    assert(strcmp(getMyElement(&l, 1).firstName, "Ioana") == 0);

    updateElem(&l, createParticipant("Ionescu","Paula" ,90));

    assert(strcmp(getMyElement(&l, 0).lastName, "Ionescu") == 0);
    assert(strcmp(getMyElement(&l, 0).firstName, "Paula") == 0);
    assert(getMyElement(&l, 0).score == 90);

    assert(size(&l) == 2);
    deleteElem(&l,1);
    assert(size(&l) == 1);

    assert(strcmp(getMyElement(&l, 0).lastName, "Ionescu") == 0);
    assert(strcmp(getMyElement(&l, 0).firstName, "Paula") == 0);
    assert(getMyElement(&l, 0).score == 90);
    MyList l2 = copyMyList(&l);
    assert(size(&l2) == 1);

    assert(strcmp(getMyElement(&l2, 0).lastName, "Ionescu") == 0);

    destroyMyList(&l);
    assert(size(&l) == 0);
}

//Controller tests:
void testController() {
    ManagerParticipants testl = createManagerParticipants();
    int errorCode = addParticipantController(&testl, "", "O", 200);
    assert(errorCode == 2);
    assert(size(&testl.lstParticipants) == 0);
    errorCode = addParticipantController(&testl, "Ionescu", "", 200);
    assert(errorCode == 3);
    assert(size(&testl.lstParticipants) == 0);
    errorCode = addParticipantController(&testl, "Ionescu", "Paula", 200);
    assert(errorCode == 4);
    assert(size(&testl.lstParticipants) == 0);
    addParticipantController(&testl, "Ionescu", "Paula", 50);
    assert(size(&testl.lstParticipants) == 1);
    errorCode = addParticipantController(&testl, "Ionescu", "Paula", 50);
    assert(errorCode == -1);
    assert(size(&testl.lstParticipants) == 1);
    addParticipantController(&testl, "Dumitrescu", "Alex", 80);
    addParticipantController(&testl, "Stan", "Briana", 90);
    addParticipantController(&testl, "Iliescu", "George", 20);
    addParticipantController(&testl, "Barbu", "Ionela", 40);
    assert(size(&testl.lstParticipants) == 5);

    MyList ls1 = sortByNameA(&testl);
    assert(size(&ls1) == 5);

    assert(strcmp(getMyElement(&ls1, 0).lastName, "Barbu") == 0);
    assert(strcmp(getMyElement(&ls1, 0).firstName, "Ionela") == 0);

    assert(strcmp(getMyElement(&ls1, 4).lastName, "Stan") == 0);
    assert(strcmp(getMyElement(&ls1, 4).firstName, "Briana") == 0);
    destroyMyList(&ls1);

    MyList ls2 = sortByNameD(&testl);
    assert(size(&ls2) == 5);

    assert(strcmp(getMyElement(&ls2, 0).lastName, "Stan") == 0);
    assert(strcmp(getMyElement(&ls2, 0).firstName, "Briana") == 0);

    assert(strcmp(getMyElement(&ls2, 4).lastName, "Barbu") == 0);
    assert(strcmp(getMyElement(&ls2, 4).firstName, "Ionela") == 0);
    destroyMyList(&ls2);

    MyList ls3 = sortByScoreA(&testl);
    assert(size(&ls3) == 5);

    assert(strcmp(getMyElement(&ls3, 0).lastName, "Iliescu") == 0);
    assert(strcmp(getMyElement(&ls3, 0).firstName, "George") == 0);

    assert(strcmp(getMyElement(&ls3, 4).lastName, "Stan") == 0);
    assert(strcmp(getMyElement(&ls3, 4).firstName, "Briana") == 0);
    destroyMyList(&ls3);

    MyList ls4 = sortByScoreD(&testl);
    assert(size(&ls4) == 5);

    assert(strcmp(getMyElement(&ls4, 0).lastName, "Stan") == 0);
    assert(strcmp(getMyElement(&ls4, 0).firstName, "Briana") == 0);

    assert(strcmp(getMyElement(&ls4, 4).lastName, "Iliescu") == 0);
    assert(strcmp(getMyElement(&ls4, 4).firstName, "George") == 0);
    destroyMyList(&ls4);

    updateParticipantController(&testl, "Ionescu", "Paula", 90);

    assert(strcmp(getMyElement(&testl.lstParticipants, 0).lastName, "Ionescu") == 0);
    assert(getMyElement(&testl.lstParticipants, 0).score == 90);

    int err = updateParticipantController(&testl, "", "Paula", 90);
    assert(err == 2);

    err = updateParticipantController(&testl, "Ionascu", "Paula", 90);
    assert(err == -1);

    MyList l2 = filterScore(&testl, 50);
    assert(size(&l2) == 2);
    destroyMyList(&l2);

    MyList l3 = filterFirstLetter(&testl, "I");
    assert(size(&l3) == 2);
    destroyMyList(&l3);

    assert(size(&testl.lstParticipants) == 5);
    deleteParticipantController(&testl, 3);
    assert(size(&testl.lstParticipants) == 4);
    err = deleteParticipantController(&testl, -2);
    assert(err == 0);
    assert(size(&testl.lstParticipants) == 4);

    destroyManagerParticipants(&testl);
}

void run_tests() {
    testCreateParticipant();

    testIterateList();

    testController();
    printf("All tests passed!\n");
}