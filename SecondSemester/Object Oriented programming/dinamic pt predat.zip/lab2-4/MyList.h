//
// Created by popla on 11-Mar-25.
//
#ifndef MYLIST_H
#define MYLIST_H

#include "entity.h"

typedef Participant TElem;
typedef struct {
    TElem* elems;
    int length;
    int capacity;
}MyList;

/*
 * Create an empty list
 * return: MyList, a new void list
 */
MyList createEmpty();

/*
 * Destroy list
 */
void destroyMyList(MyList* myList);

/*
 * Get an element from the list
 * param: myList - MyList*, the given list
 *        poz - position of element, need to be valid
 * return: element found on position poz
 */
TElem getMyElement(MyList* myList, int poz);

/*
 * return number of elements in the list
 */
int size(MyList* myList);

/*
 * Add element into the list
 * param: myList - MyList*, the given list
 *        el - ElemType, el to be added
 * post: element is added to the end of the list
 */
void addElem(MyList* myList, TElem eL);

/*
 * Delete an element from position poz
 * param: myList - MyList*, the given list
 *        poz - position of element, need to be valid
 * return; deleted element
 */
TElem deleteElem(MyList* myList, int poz);

/*
 * Update score of one participant
 * param: myList - MyList*, the given list
 *        el - ElemType, el to be added
 * post: entity score is modified
 */

TElem updateElem(MyList* myList, TElem eL);

/*
 * Search for a participant in the list
 * params: lastName, firstName - str, name of participant
 * return: participant position if fount, -1 otherwise
 */
int findElem(MyList* myList, char* lastName, char* firstName);

/*
 * Make a shallow copy of the list
 * return MyList containing the same elements as original list
 */
MyList copyMyList(MyList* myList);

#endif //MYLIST_H
