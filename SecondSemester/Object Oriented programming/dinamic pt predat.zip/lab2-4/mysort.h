//
// Created by popla on 13-Mar-25.
//

#ifndef MYSORT_H
#define MYSORT_H
#include "MyList.h"

/*
 * Type of comparing function for 2 elements
 * return: 0 if equals, 1 if p1>p2, -1 otherwise
 */
typedef int(*CmpFct)(Participant* p1, Participant* p2);

/*
 * Sorting in place
 * cmp - relation for comparing
 */
void sort(MyList* myList, CmpFct cmp);
#endif //MYSORT_H
