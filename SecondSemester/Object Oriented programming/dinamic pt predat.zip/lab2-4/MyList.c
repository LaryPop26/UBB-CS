//
// Created by popla on 11-Mar-25.
//

#include "MyList.h"
#include <stdlib.h>
#include <string.h>

MyList createEmpty() {
    MyList participants;
    participants.capacity = 2;
    participants.elems = (TElem*)malloc(participants.capacity * sizeof(TElem));
    participants.length = 0;
    return participants;
}

void destroyMyList(MyList* myList) {
    for (int i = 0; i < size(myList); i++) {
        Participant p = getMyElement(myList, i);
        destroyParticipant(&p);
    }
    free(myList->elems);
    myList->length = 0;
}

void addElem(MyList* myList, TElem eL) {
    if (myList->capacity == myList->length) {
        int newCapacity = myList->capacity * 2;
        TElem* newElements = (TElem*)malloc(newCapacity * sizeof(TElem));
        for (int i = 0; i < myList->length; i++) {
            newElements[i] = myList->elems[i];
        }
        free(myList->elems);
        myList->elems = newElements;
        myList->capacity = newCapacity;
    }
    myList->elems[myList->length] = eL;
    myList->length++;
}

TElem getMyElement(MyList* myList, int poz) {
    return myList->elems[poz];
}

TElem deleteElem(MyList* myList, int poz) {
    TElem delElem = getMyElement(myList, poz);
    for (int i = poz; i < myList->length-1; i++) {
        myList->elems[i] = myList->elems[i+1];
    }
    myList->length--;
    return delElem;
}

TElem updateElem(MyList* participants, Participant participant) {
    for (int i = 0; i < participants->length; i++) {
        if (strcmp(participant.lastName,participants->elems[i].lastName)==0
            && strcmp(participant.firstName, participants->elems[i].firstName)==0) {
            free(participants->elems[i].lastName);
            free(participants->elems[i].firstName);
            participants->elems[i] = participant;
        }
    }
    return participant;
}

int findElem(MyList* participants, char* lastName, char* firstName) {
    for (int i = 0; i < participants->length; i++) {
        if (strcmp(participants->elems[i].lastName, lastName) == 0 &&
            strcmp(participants->elems[i].firstName, firstName) == 0) {
            return i;
            }
    }
    return -1;
}

int size(MyList* myList) {
    return myList->length;
}

MyList copyMyList(MyList* myList) {
    MyList copyParticipants=createEmpty();
    for (int i = 0; i < size(myList); i++) {
        TElem el=getMyElement(myList, i);
        addElem(&copyParticipants, copyParticipant(&el));
    }
    return copyParticipants;
}