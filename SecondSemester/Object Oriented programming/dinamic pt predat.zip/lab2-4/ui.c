//
// Created by popla on 12-Mar-25.
//

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "MyList.h"
#include "controller.h"
#include "tests.h"

void printMenu() {
    printf("Programing contest Main Menu.\n");
    printf("1. Add participant\n");
    printf("2. Update participant\n");
    printf("3. Delete participant\n");
    printf("4. Filter participants\n");
    printf("5. Sort participants\n");
    printf("6. Show all participants\n");
    printf("0. Exit\n");
}

void filterMenu() {
    printf("Filter participants.\n");
    printf("1. Score under a value\n");
    printf("2. Lastname starting with a letter\n");
}

void sortMenu() {
    printf("Sort participants.\n");
    printf("1. Ascending names\n");
    printf("2. Descending names\n");
    printf("3. Ascending score\n");
    printf("4. Descending score\n");
}

void show(MyList* participants) {
    if (size(participants) == 0) printf("No participants\n");
    for (int i=0; i<size(participants); i++) {
        Participant p = getMyElement(participants, i);
        printf("%d. Name: %s %s | Score: %d\n",i+1,p.lastName, p.firstName, p.score);
    }
}

void addParticipantUI(ManagerParticipants* manager) {
    int score;
    char lastName[30], firstName[30];
    getchar();
    printf("Enter last name: ");
    fgets(lastName, 30, stdin);
    printf("Enter first name: ");
    fgets(firstName, 30, stdin);
    lastName[strcspn(lastName, "\n")] = 0;
    firstName[strcspn(firstName, "\n")] = 0;

    printf("Enter score: ");
    scanf("%d", &score);
    getchar();

    int errorCode = addParticipantController(manager, lastName, firstName, score);
    if (errorCode != 0) printf("Error while adding participant\n");
    else printf("Successfully added Participant\n");
}

void addDefault(ManagerParticipants* manager) {
    addParticipantController(manager,"Ionescu", "Diana", 100);
    addParticipantController(manager, "Dumitrescu", "Alex", 80);
    addParticipantController(manager, "Stan", "Briana", 90);
    addParticipantController(manager, "Iliescu", "George", 20);
    addParticipantController(manager, "Barbu", "Ionela", 40);
    printf("\n ");
}

void updateParticipantUI(ManagerParticipants* manager) {
    int score;
    char lastName[30], firstName[30];
    getchar();
    printf("Enter last name: ");
    fgets(lastName, 30, stdin);
    lastName[strcspn(lastName, "\n")] = 0;
    printf("Enter first name: ");
    fgets(firstName, 30, stdin);
    firstName[strcspn(firstName, "\n")] = 0;

    printf("Enter score: ");
    scanf("%d", &score);
    getchar();

    int errorCode = updateParticipantController(manager, lastName, firstName, score);
    if (errorCode != 0) printf("Error while modifing participant\n");
    else printf("Successfully modified Participant\n");
}

void deleteParticipantUI(ManagerParticipants* manager) {
    int poz;
    printf("Enter position to be deleted: ");
    scanf("%d", &poz);

    int errorCode = deleteParticipantController(manager, poz-1);
    if (errorCode != 0) printf("Error while deleting participant\n");
    else printf("Successfully deleted Participant\n");
}

void filterScoreUI(ManagerParticipants* manager) {
    int score;
    printf("Enter maximum score: ");
    scanf("%d", &score);
    MyList filteredList = filterScore(manager, score);
    show(&filteredList);
    destroyMyList(&filteredList);
}

void filterFirstLetterUI(ManagerParticipants * manager) {
    char firstLetter[2];
    getchar();
    printf("Enter first letter: ");
    fgets(firstLetter, 2, stdin);
    firstLetter[strcspn(firstLetter, "\n")] = 0;
    MyList filteredList = filterFirstLetter(manager, firstLetter);
    show(&filteredList);
    destroyMyList(&filteredList);
}

void sortByNameAUI(ManagerParticipants* manager) {
    MyList sortedList = sortByNameA(manager);
    show(&sortedList);
    destroyMyList(&sortedList);
}

void sortByNameDUI(ManagerParticipants* manager) {
    MyList sortedList = sortByNameD(manager);
    show(&sortedList);
    destroyMyList(&sortedList);
}

void sortByScoreAUI(ManagerParticipants* manager) {
    MyList sortedList = sortByScoreA(manager);
    show(&sortedList);
    destroyMyList(&sortedList);
}

void sortByScoreDUI(ManagerParticipants* manager) {
    MyList sortedList = sortByScoreD(manager);
    show(&sortedList);
    destroyMyList(&sortedList);
}

void run() {
    run_tests();
    bool is_running = true;
    ManagerParticipants managerParticipants = createManagerParticipants();
    addDefault(&managerParticipants);
    while (is_running) {
        printMenu();
        printf(">>>");
        short int cmd;
        scanf("%hd", &cmd);
        switch (cmd) {
            case 1:
                printf("Add participant\n");
                addParticipantUI(&managerParticipants);
                break;
            case 2:
                printf("Update participant\n");
                updateParticipantUI(&managerParticipants);
                break;
            case 3:
                printf("Delete participant\n");
                deleteParticipantUI(&managerParticipants);
                break;
            case 4:
                filterMenu();
                short int option1;
                printf(">>> ");
                scanf("%hd", &option1);
                switch (option1) {
                    case 1:
                        printf("Filter after score\n");
                        filterScoreUI(&managerParticipants);
                        break;
                    case 2:
                        printf("Filter after first letter\n");
                        filterFirstLetterUI(&managerParticipants);
                        break;
                    default:
                        break;
                }
                break;
            case 5:
                sortMenu();
                short int option2;
                printf(">>> ");
                scanf("%hd", &option2);
                switch (option2) {
                    case 1:
                        printf("sort1\n");
                        sortByNameAUI(&managerParticipants);
                        break;
                    case 2:
                        printf("sort2\n");
                        sortByNameDUI(&managerParticipants);
                        break;
                    case 3:
                        printf("sort3\n");
                        sortByScoreAUI(&managerParticipants);
                        break;
                    case 4:
                        printf("sort4\n");
                        sortByScoreDUI(&managerParticipants);
                        break;
                    default:
                        break;
                }
                break;
            case 6:
                printf("List of participants: \n");
                show(&managerParticipants.lstParticipants);
                break;
            case 0:
                is_running = false;
                destroyManagerParticipants(&managerParticipants);
                break;
            default:
                printf("Invalid command\n");
                break;
        }
    }
}

int main(void) {
    run();
}