//
// Created by popla on 11-Mar-25.
//
#include "entity.h"

#include <stdlib.h>
#include <string.h>

Participant createParticipant(char* lastName, char* firstName, int score) {
    Participant p;
    size_t lenLastName = strlen(lastName)+1;
    p.lastName = malloc(lenLastName * sizeof(char));
    strncpy(p.lastName,lastName, lenLastName-1);
    p.lastName[lenLastName - 1] = '\0';

    size_t lenFirstName = strlen(firstName)+1;
    p.firstName = malloc(lenFirstName * sizeof(char));
    strncpy(p.firstName,firstName, lenFirstName-1);
    p.firstName[lenFirstName - 1] = '\0';

    p.score = score;
    return p;
}

void destroyParticipant(Participant* p) {
    free(p->firstName);
    free(p->lastName);

    p->firstName = NULL;
    p->lastName = NULL;
    p->score = -1;
}

Participant copyParticipant(Participant* p) {
    return createParticipant(p->lastName, p->firstName, p->score);
}